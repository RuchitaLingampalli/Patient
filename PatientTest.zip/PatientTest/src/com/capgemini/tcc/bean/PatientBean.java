package com.capgemini.tcc.bean;

import java.util.Date;
import java.time.LocalDate;
public class PatientBean {
   int patientAge;
   int patientId;
   String patientName;
   String patientMob;
   String patientDesc;
   LocalDate ConsultationDate;
   public PatientBean() {
	   
   }
   public PatientBean(int patientAge,int patientId,String patientName,String patientMob,String patientDesc) {
	   
	   this.patientAge=patientAge;
	   this.patientId=patientId;
	   this.patientName=patientName;
	   this.patientMob=patientMob;
	   this.patientDesc=patientDesc;
   }
   
   public PatientBean(int patientAge,int patientId,String patientName,String patientMob,String patientDesc,LocalDate cdate) {
	   this.patientAge=patientAge;
	   this.patientId=patientId;
	   this.patientName=patientName;
	   this.patientMob=patientMob;
	   this.patientDesc=patientDesc;
	   this.ConsultationDate=cdate;
   }
   
@Override
public String toString() {
	return "PatientBean [patientAge=" + patientAge + ", patientId=" + patientId + ", patientName=" + patientName
			+ ", patientMob=" + patientMob + ", patientDesc=" + patientDesc + ", ConsultationDate=" + ConsultationDate
			+ "]";
}
public int getPatientAge() {
	return patientAge;
}
public void setPatientAge(int patientAge) {
	this.patientAge = patientAge;
}
public int getPatientId() {
	return patientId;
}
public void setPatientId(int patientId) {
	this.patientId = patientId;
}
public String getPatientName() {
	return patientName;
}
public void setPatientName(String patientName) {
	this.patientName = patientName;
}
public String getPatientMob() {
	return patientMob;
}
public void setPatientMob(String patientMob) {
	this.patientMob = patientMob;
}
public String getPatientDesc() {
	return patientDesc;
}
public void setPatientDesc(String patientDesc) {
	this.patientDesc = patientDesc;
}
public LocalDate getConsultationDate() {
	return ConsultationDate;
}
public void setConsultationDate(LocalDate consultationDate) {
	ConsultationDate = consultationDate;
}


   
}
