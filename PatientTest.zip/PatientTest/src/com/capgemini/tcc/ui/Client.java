package com.capgemini.tcc.ui;
import java.time.LocalDate;
import java.util.Date;
import java.util.Locale;
import java.util.Scanner;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.service.PatientService;

public class Client {
public static void main(String args[]) {
	int ch;
	char choice;
	PatientService ps=new PatientService();
	Scanner sc=new Scanner(System.in);
	do {
	System.out.println("*******Menu Display******* \n 1.Add Patient Information \n 2.Search Patient by ID \n 3.Exit");
	System.out.println("Enter your choice:");
    ch=sc.nextInt();
    switch(ch) {
    
    case 1 :
    	
    	System.out.println("Enter patient Age:");
    	int age=sc.nextInt();
    	System.out.println("Enter patient ID:");
    	int id=sc.nextInt();
    	System.out.println("Enter patient name:");
    	String name=nameCheck(sc.next());
    	System.out.println("Enter patient mobile no:");
    	String mobno=mobilenoCheck(sc.next());
    	System.out.println("Enter patient Description:" );
    	String Desc=sc.next();
    	System.out.println("Enter consultation date:"+LocalDate.now());
    	//LocalDate date=LocalDate.now();
    	PatientBean Patient=new PatientBean(age,id,name,mobno,Desc);
    	ps.addPatientDetails(Patient);
    	System.out.println("Patient details added successfully for patientId:"+id);
    	break;
    case 2:
    	System.out.println("Enter Patient Id:");
        id=sc.nextInt();
       // ps.getPatientDetails(id);
        System.out.println(ps.getPatientDetails(id));
        break;
    case 3:
    	System.out.println("Thank you");
    	System.exit(0);
    	break;
    	}
    System.out.println("do you want to continue(y/n)...?:");
		choice =sc.next().charAt(0);
		if (choice == 'y'|| choice =='Y')
			continue;
		else {
			
			System.out.println("Thank you");
			System.exit(0);
		} 		
	} while(ch!=3);
	sc.close();

}


public static String nameCheck(String name) {
	while(true) {
	if(name.length()>3 && Character.isUpperCase(name.charAt(0))) {
		return name;
	}
		else { 
			System.out.println("InValid Name");
			System.out.println("Enter again:");
		}
	}
}	
public static String mobilenoCheck(String mobno) {
	while(true) {
		if(mobno.length()>10) {
			System.out.println("Invalid mobno");
			System.out.println("Enter again:");
		}
			else {
				return mobno;
			}
		}
	
}
}


		
		
	
	

