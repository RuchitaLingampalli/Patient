package com.capgemini.tcc.exception;

public class PatientException extends RuntimeException{
 public PatientException() {
	 
 }
 public PatientException(String string) {
	 System.out.println(string);
 }
}
