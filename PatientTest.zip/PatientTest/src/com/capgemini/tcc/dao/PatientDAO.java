package com.capgemini.tcc.dao;

import java.util.HashMap;
import java.util.LinkedList;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;

public class PatientDAO implements IPatientDAO{
	LinkedList<PatientBean> ll= new LinkedList<PatientBean>();
	//HashMap<Integer,PatientBean> hm=new HashMap<Integer,PatientBean>();
    PatientBean Patient;
	@Override
	public void addPatientDetails(PatientBean Patient) {
		//hm.put(Patient.getPatientId(),Patient);
		ll.add(Patient);
		// TODO Auto-generated method stub
		System.out.println("added");
		
		
	}

	@Override
	public PatientBean getPatientDetails(int PatientId) throws PatientException {
		PatientBean Patient=ll.get(0);
		//System.out.println("Patient Details are:"+get(PatientId));
		// TODO Auto-generated method stub
		return Patient;
	}

	
}
