package com.capgemini.tcc.dao;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;

public interface IPatientDAO {
 
	void addPatientDetails (PatientBean Patient);
    PatientBean getPatientDetails(int PatientId) throws PatientException;
	
	
}
