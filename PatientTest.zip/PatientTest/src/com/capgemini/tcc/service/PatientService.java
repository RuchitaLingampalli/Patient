package com.capgemini.tcc.service;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exception.PatientException;

public class PatientService implements IPatientService {

	PatientDAO patd=new PatientDAO();
	
	@Override
	public void addPatientDetails(PatientBean Patient) {
		
		patd.addPatientDetails(Patient);
		// TODO Auto-generated method stub
		
	}

	@Override
	public PatientBean getPatientDetails(int PatientId) throws PatientException {
	PatientBean	Patient=patd.getPatientDetails(PatientId);
		// TODO Auto-generated method stub
		return Patient;
	}

}
